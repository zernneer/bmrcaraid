package com.example.mike.caraid4.Parts;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mike.caraid4.PartSearch;
import com.example.mike.caraid4.Parts.ProblemsActivity;
import com.example.mike.caraid4.R;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Renz on 7/27/2016.
 */
public class PartsFragment extends Fragment {

    DatabaseReference partsRef = FirebaseDatabase.getInstance().getReference().child("Parts");

    //ArrayList<String> partList = new ArrayList<>();

    ListView pListView;
    EditText searchBar;
    Button searchBtn;
    //TextView pTextView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_parts, container, false);
        partsRef.keepSynced(true);
        //getActivity().getActionBar().setTitle("Parts");
        pListView = (ListView) rootView.findViewById(R.id.partListView);
        //pTextView = (TextView)view.findViewById(R.id.partTextView);
        searchBar = (EditText) rootView.findViewById(R.id.searchbar);
        searchBtn = (Button) rootView.findViewById(R.id.searchbtn);
        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), PartSearch.class);
                    i.putExtra("part", searchBar.getText().toString());
                startActivity(i);
            }
        });

        FirebaseListAdapter<String> adapter = new FirebaseListAdapter<String>(getActivity(), String.class, android.R.layout.simple_list_item_1, partsRef) {
            @Override
            protected void populateView(View v, String model, int position) {
                final TextView textView = (TextView) v.findViewById(android.R.id.text1);
                textView.setText(model);

                textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getActivity(), ProblemsActivity.class);
                            intent.putExtra("ref", textView.getText().toString());
                        startActivity(intent);
                    }
                });
            }
        };
        pListView.setAdapter(adapter);
    }

}
