package com.example.mike.caraid4;
import java.lang.*;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mike.caraid4.Parts.ProblemsActivity;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class PartSearch extends AppCompatActivity {
    DatabaseReference partsRef = FirebaseDatabase.getInstance().getReference().child("Parts");
    ListView partlistview;
    String part;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part_search);

        partlistview = (ListView) findViewById(R.id.partListView);

        Intent intent = getIntent();
        part = intent.getExtras().getString("part");
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseListAdapter<String> adapter = new FirebaseListAdapter<String>(this, String.class, android.R.layout.simple_list_item_1, partsRef) {
            @Override
            protected void populateView(View v, String model, int position) {
                String tmodel = model;
                String tpart = part;
                tpart = tpart.toLowerCase();
                tmodel = tmodel.toLowerCase();
                if(tmodel.contains(tpart)){
                    final TextView textView = (TextView) v.findViewById(android.R.id.text1);
                    textView.setText(model);

                    textView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent = new Intent(PartSearch.this, ProblemsActivity.class);
                                intent.putExtra("ref", textView.getText().toString());
                            startActivity(intent);
                        }
                    });
                }
            }
        };
        partlistview.setAdapter(adapter);
    }
}
