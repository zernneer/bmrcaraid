package com.example.mike.caraid4.Parts;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mike.caraid4.R;
import com.firebase.client.Firebase;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class ProblemViewActivity extends AppCompatActivity {
    DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    DatabaseReference sympRef;
    DatabaseReference symptomsRef;
    DatabaseReference solutionRef;
    //DatabaseReference ratingRef;

    String problemRef;

    TextView probTextView;
    //TextView sympTextView;
    TextView solTextView;
    ListView sympList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem_view);
        root.keepSynced(true);

        Intent intent = getIntent();
        problemRef = intent.getExtras().getString("problemRef");
        sympRef = FirebaseDatabase.getInstance().getReference().child("Symptoms").child(problemRef);
        //symptomsRef = FirebaseDatabase.getInstance().getReference().child("Symptoms").child(problemRef);
        //solutionRef = FirebaseDatabase.getInstance().getReference().child("Solutions").child(problemRef);

        probTextView = (TextView)findViewById(R.id.probemTextView);
        sympList = (ListView) findViewById(R.id.symptomListView);
        solTextView = (TextView)findViewById(R.id.solutionTextView);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(problemRef);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
    }

    @Override
    protected void onStart() {
        super.onStart();
        probTextView.setText(problemRef);

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                solTextView.setText(dataSnapshot.child("Solutions").child(problemRef).getValue().toString());
                //sympTextView.setText(dataSnapshot.child("Symptoms").child(problemRef).getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        FirebaseListAdapter<String> adapter = new FirebaseListAdapter<String>(this, String.class, android.R.layout.simple_list_item_1, sympRef) {
            @Override
            protected void populateView(View v, String model, int position) {
                final TextView textView = (TextView) v.findViewById(android.R.id.text1);
                textView.setText(model);
            }
        };
        sympList.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        return true;
    }
}
